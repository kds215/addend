import addend

def main():
    addend.main()

# to launch addend from command line
# see https://python-packaging.readthedocs.io/en/latest/command-line-scripts.html
# #the-console-scripts-entry-point